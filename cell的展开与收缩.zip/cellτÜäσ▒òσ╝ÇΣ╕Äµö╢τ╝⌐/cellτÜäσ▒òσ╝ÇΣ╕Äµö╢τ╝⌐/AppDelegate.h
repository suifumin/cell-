//
//  AppDelegate.h
//  cell的展开与收缩
//
//  Created by suifumin on 2017/11/1.
//  Copyright © 2017年 suifumin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


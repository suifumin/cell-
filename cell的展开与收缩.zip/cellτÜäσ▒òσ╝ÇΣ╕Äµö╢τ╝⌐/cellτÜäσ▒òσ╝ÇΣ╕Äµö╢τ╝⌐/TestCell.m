//
//  TestCell.m
//  cell的展开与收缩
//
//  Created by suifumin on 2017/11/1.
//  Copyright © 2017年 suifumin. All rights reserved.
//

#import "TestCell.h"
#define RANDOMNUM (arc4random_uniform(256)/255.0)
@interface TestCell ()
@property(nonatomic,strong)UIButton *selectedBtn;
@end
@implementation TestCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.titleLable = [[UILabel alloc]init];
        self.titleLable.textColor = [UIColor blackColor];
        self.titleLable.font = [UIFont systemFontOfSize:10];
        
        [self.contentView addSubview:self.titleLable];
        
        self.contentLable = [[UILabel alloc]init];
        self.contentLable.textColor = [UIColor blackColor];
        self.contentLable.font = [UIFont systemFontOfSize:10];
       
        self.contentLable.text = self.testModel.content;
        self.contentLable.numberOfLines = 0;
        [self.contentView addSubview:self.contentLable];
        
        
        self.openBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.openBtn setTitle:@"展开" forState:UIControlStateNormal];
        [self.openBtn  setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.openBtn setTitle:@"收缩" forState:UIControlStateSelected];
        [self.openBtn setTitleColor:[UIColor blackColor] forState:UIControlStateSelected];
        [self.openBtn addTarget:self action:@selector(clickOpenBtn:) forControlEvents:UIControlEventTouchDown];
        [self.contentView addSubview:self.openBtn];
         self.contentView.backgroundColor = [UIColor colorWithRed:RANDOMNUM green:RANDOMNUM blue:RANDOMNUM alpha:1];
    }
    return self;
}
-(void)layoutSubviews{
    [super layoutSubviews];
    self.titleLable.text = self.testModel.title;
    self.contentLable.text = self.testModel.content;
    self.titleLable.frame = CGRectMake(0, 0, self.frame.size.width-50, self.frame.size.height/3);
    self.contentLable.frame = CGRectMake(0, self.frame.size.height/3, self.frame.size.width-50, 2*self.frame.size.height/3);
    self.openBtn.frame = CGRectMake(self.frame.size.width-50, 0, 50, self.frame.size.height);
    if(self.testModel.isOpen){
        NSDictionary *dic = @{NSFontAttributeName:[UIFont systemFontOfSize:10]};
        CGSize size = [self.testModel.content boundingRectWithSize:CGSizeMake(self.frame.size.width-50, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil].size;
         self.contentLable.frame = CGRectMake(0, self.frame.size.height/3, self.frame.size.width-50, size.height);
        
    }else{
        
         self.contentLable.frame = CGRectMake(0, self.frame.size.height/3, self.frame.size.width-50, 2*self.frame.size.height/3);
    }
}
-(void)clickOpenBtn:(UIButton *)btn{
    btn.selected = !btn.selected;
    self.testModel.isOpen = !self.testModel.isOpen;
    if(self.testBlock){
        
        self.testBlock();
    }
    
}
+ (CGFloat)cellDefaultHeight:(TestModel *)model
{
    //默认cell高度
    return 44;
}

+ (CGFloat)cellMoreHeight:(TestModel *)model
{
    
    NSDictionary *dic = @{NSFontAttributeName:[UIFont systemFontOfSize:10]};
    CGSize size = [model.content boundingRectWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width -50, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:dic context:nil].size;
    return size.height + 50;
}
@end

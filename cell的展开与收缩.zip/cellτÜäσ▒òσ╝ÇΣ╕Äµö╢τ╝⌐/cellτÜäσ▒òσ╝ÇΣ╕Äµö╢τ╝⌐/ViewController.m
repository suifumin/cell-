//
//  ViewController.m
//  cell的展开与收缩
//
//  Created by suifumin on 2017/11/1.
//  Copyright © 2017年 suifumin. All rights reserved.
//

#import "ViewController.h"
#import "TestCell.h"
#import "TestModel.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSArray *dataArray;
@property(nonatomic,strong)NSMutableArray *modelArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
            NSDictionary *dic0 = @{@"title":@"第一篇",@"content":@"党的十九大闭幕仅一周，中共中央总书记、国家主席、中央军委主席习近平带领中共中央政治局常委李克强、栗战书、汪洋、王沪宁、赵乐际、韩正，于31日专程从北京前往上海和浙江嘉兴"};
            NSDictionary *dic1 = @{@"title":@"第二篇",@"content":@"31日上午，习近平等一下飞机，就来到位于上海市兴业路76号的中共一大会址。这座饱经沧桑的石库门建筑，1952年9月修复并对外开放，在繁华的现代化都市中庄严肃穆。96年前"};
           NSDictionary *dic2 = @{@"title":@"第三篇",@"content":@"习近平等在兴业路下车后，步行来到中共一大会址纪念馆。习近平在上海工作期间曾3次到这里。在这里，习近平首先瞻仰了中共一大会议室原址。这个18平方米的房间按照当年会议场景复原布置。习近平久久凝视，叮嘱一定要把会址保护好"};
            NSDictionary *dic3 = @{@"title":@"第四篇",@"content":@"这里是招募界面，大部分的角色就是从这里产出，每天免费招募最多有8次。每隔一段时间恢复一次。每招募10次稳定获得一个紫色忍者，十连的话也是一样稳定获得一个"};
            NSDictionary *dic4 = @{@"title":@"第五篇",@"content":@"本款宇智波鼬粘土人再现了他在《火影忍者》故事里的衣装形象，此外还附赠有可替换的“冷酷脸”、“笑脸”和使用天照后眼睛受伤的“痛苦脸”表情。而在将鼬身穿的晓组织外衣脱下"};
    self.dataArray = @[dic0,dic1,dic2,dic3,dic4,dic0,dic1,dic2,dic3,dic4,dic0,dic1,dic2,dic3,dic4,dic0,dic1,dic2,dic3,dic4,dic0,dic1,dic2,dic3,dic4,dic0,dic1,dic2,dic3,dic4];
    self.modelArray = [NSMutableArray array];
    for (NSDictionary *dic in self.dataArray) {
        TestModel *model = [[TestModel alloc]initWithDic:dic];
        [self.modelArray addObject:model];
    }
    
    [self setTableView];
    
}
-(void)setTableView{
    UITableView *tableView = [[UITableView alloc]initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    [self.view addSubview:tableView];
    self.tableView = tableView;
    self.tableView.estimatedRowHeight = 44;//(数据较多的时候，后几条数据出现动画混乱的解决方法)
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataArray.count;
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *recell = @"recell";
    TestModel *model = self.modelArray[indexPath.row];
    TestCell *cell = [tableView dequeueReusableCellWithIdentifier:recell];
   
    if(!cell){
        
        cell = [[TestCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:recell];
    }
    cell.testBlock = ^{
        [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationTop];
    };
    cell.testModel = model;
    return cell;
}

-(NSMutableArray*)modelArray{
    if (!_modelArray) {
        _modelArray = [NSMutableArray array];
    }
    
    return _modelArray;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    TestModel *model =self.modelArray[indexPath.row];
    NSLog(@"**********%@",model.title);
    if(model.isOpen){
        return    [TestCell cellMoreHeight:model];
        
    }else{
        return  [TestCell cellDefaultHeight:model];
    }
}
@end

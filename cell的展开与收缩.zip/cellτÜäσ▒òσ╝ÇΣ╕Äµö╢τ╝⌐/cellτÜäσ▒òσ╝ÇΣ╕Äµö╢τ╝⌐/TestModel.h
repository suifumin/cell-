//
//  TestModel.h
//  cell的展开与收缩
//
//  Created by suifumin on 2017/11/1.
//  Copyright © 2017年 suifumin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TestModel : NSObject
@property(nonatomic,copy)NSString *title;
@property(nonatomic,copy)NSString *content;
@property(nonatomic,assign)BOOL isOpen;
-(instancetype)initWithDic:(NSDictionary *)dic;
@end

//
//  TestModel.m
//  cell的展开与收缩
//
//  Created by suifumin on 2017/11/1.
//  Copyright © 2017年 suifumin. All rights reserved.
//

#import "TestModel.h"

@implementation TestModel
-(instancetype)initWithDic:(NSDictionary *)dic{
    if(self = [super init]){
        _title = dic[@"title"];
        _content = dic[@"content"];
        _isOpen = NO;
    }
    return self;
}
@end

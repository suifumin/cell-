//
//  TestCell.h
//  cell的展开与收缩
//
//  Created by suifumin on 2017/11/1.
//  Copyright © 2017年 suifumin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TestModel.h"
typedef void(^testBlock)();
@interface TestCell : UITableViewCell
@property(nonatomic,strong)TestModel*testModel;
@property(nonatomic,strong)UILabel *titleLable;
@property(nonatomic,strong)UILabel *contentLable;
@property(nonatomic,strong)UIButton *openBtn;
@property(nonatomic,copy)testBlock testBlock;
+ (CGFloat)cellDefaultHeight:(TestModel *)model;
///展开后的高度
+(CGFloat)cellMoreHeight:(TestModel *)model;
@end
